package pl.lukabrasi.transportapp.form;

import lombok.Data;

@Data
public class FreighterForm {

    private String freighterName;
    private String freighterPerson;
    private String freighterPhone;
    private String freighterEmail;
    private String freighterInfo;
}
