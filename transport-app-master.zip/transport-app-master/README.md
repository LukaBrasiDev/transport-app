TRANSPORT APP

Aplikacja dla spedytorów do zarządzania zleceniami transportu ładunków

+ baza zleceń (numery, daty, załadunki, rozładunki, ceny, status)
+ baza przewoźników
+ baza fabryk
+ baza użytkowników
